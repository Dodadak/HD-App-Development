# 운행일지 부품 v0.14.10

메인 앱에서 인증한 사용자 ID, 표시 이름, 관리자 여부를 전달받습니다. 운행일지 자체 계정 생성, 비밀번호, 로그인 화면은 제거했습니다.

새 폴더에 압축을 풀고 Android Studio에서 `Hyundai_SDK` 폴더를 엽니다. 실행 절차는 README_UI.md에서 확인하세요.

## PC 콘솔 실행

프로젝트 루트에서 실행합니다. Java 11 이상이 필요합니다.

```powershell
java -jar .\triplog\build\triplog-cli.jar
```

저장 파일 경로, 사용자 ID, 표시 이름, 관리자 여부(y/n)를 차례대로 입력합니다.
예시 값은 `data/triplog.bin`, `admin-1`, `관리자 1`, `y`입니다.
이 입력은 메인 앱을 대신하는 테스트 데이터입니다. 비밀번호는 사용하지 않습니다.

다음 명령은 한 줄씩 입력합니다.

```text
start 1000
finish 1012
review latest
```

목적을 입력하고 BUSINESS 또는 PERSONAL을 선택한 뒤 y로 확정합니다.
`list`로 조회하고 `export 2026-11 monthly.csv`로 내보냅니다.
`details latest`에서 회사·차량·운전자 정보를 입력하면 `report 2026-11 monthly.html`로 월간 보고서를 생성합니다.
날짜는 실제 운행이 저장된 월을 사용합니다. `help`에 전체 명령이 있습니다.
`quit` 후 같은 저장 파일과 사용자 ID로 실행하면 기록을 복원합니다.

## Pleos 에뮬레이터 실행

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\start-pleos-triplog.ps1
```

AVD 부팅, 콘솔 연결, APK 설치 후 PC에서 사용자 ID·표시 이름·관리자 여부를 입력합니다.
화면에서 운행일지를 선택하면 바로 열립니다.
AVD가 여러 개라면 `-AvdName "정확한 AVD 이름"`을 추가합니다.
콘솔에서 입력한 사용자 데이터는 debug 앱의 private files에 저장되며 다음 실행 때 덮어씁니다.
이 스크립트는 테스트 앱을 재시작하므로 진행 중인 운행 테스트에서는 재실행 시 복원 상태를 확인하세요.

Virtual Console에서 P로 기준 누적거리를 읽힌 다음 D와 거리 증가로 출발을 확인합니다.
P에서 거리를 5초 이상 유지한 뒤 화면에서 종료를 확인하고 목적과 분류를 저장합니다.
내비 정보는 Pleos 기본 내비의 길 안내 시작 후 운행일지로 돌아와 확인합니다.
차량 신호 수집은 현재 화면이 보이는 동안 실행됩니다.

## 소스 재빌드와 검증

```powershell
.\gradlew.bat :triplog:jar :triplog:testJar :triplog:moduleCheck
.\gradlew.bat :app:assembleDebug
```

첫 빌드에는 Gradle·Kotlin·Android·Pleos 의존성 다운로드가 필요합니다.
동봉된 JAR는 수정된 Kotlin 소스로 빌드한 콘솔 실행본입니다.

## 전달 내용

- `triplog/core` — Android 의존성이 없는 기록·권한·차량 판단·보고서 로직
- `triplog/cli` — 메인 앱 역할을 대신하는 콘솔 입력 예제
- `triplog/tests` — 외부 사용자·기록 격리·복원·보고서·모의 차량 검증
- `app/src/main` — 운행일지 하위 화면과 Pleos 어댑터
- `app/src/debug` — 단독 테스트용 홈, 실제 팀 앱 이식 시 제외
- `TEAM_INTEGRATION.md` — 메인 앱 연결 코드와 책임 범위

기존 코어의 직렬화 데이터 구조는 이전 운행 기록을 읽기 위해 유지합니다.
이전 계정의 salt/hash는 사용자 연결 시 저장소에서 제거하며 인증에 사용하지 않습니다.
기존 기록의 운전자 ID를 유지해야 같은 사용자의 기록으로 조회됩니다.
한 저장소는 한 차량의 운행 기록에 사용하고, 차량이 여러 대면 차량별 저장소를 전달하세요.

동봉된 테스트 실행본은 다음 명령으로 실행합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\test-triplog-module.ps1
```
