# 팀 앱 연결 · v0.14.10

## Android 화면 열기

팀의 기존 MainActivity 또는 메뉴에서 인증한 사용자 정보를 전달합니다.

```kotlin
val user = TripLogUser(
    id = signedInUser.id,
    displayName = signedInUser.name,
    isAdmin = signedInUser.isAdmin
)
startActivity(TripLogScreen.intent(this, user))
```

`TripLogScreen`은 같은 앱의 내부 `TripLogActivity`를 여는 Intent를 만듭니다.
인증과 권한의 신뢰성은 메인 앱이 책임집니다. 외부 Intent나 사용자 입력을 실제 관리자 권한의 근거로 사용하면 안 됩니다.
TripLogActivity는 exported=false로 유지합니다. 배포 빌드에서는 메인 앱이 사용자 정보를 전달해야 기록을 열 수 있습니다. 테스트 빌드는 실행 스크립트가 준비한 앱 내부 테스트 사용자 파일을 사용할 수 있습니다.
테스트용 MainActivity는 `app/src/debug`에 있으며 팀의 MainActivity로 복사할 필요가 없습니다.

화면 연결에는 `TripLogScreen`, `TripLogActivity`, `TripLogHost`, navigation/vehicle 어댑터, 테마 리소스와 코어가 필요합니다.
AndroidManifest.xml의 권한·내부 Activity·android.car 항목, app/build.gradle.kts의 Pleos 의존성을 팀 설정에 병합합니다.
TripLogHost의 저장 파일 경로는 `noBackupFilesDir/triplog/state.bin`입니다.

## UI 없이 공용 코어 사용

```kotlin
val user = TripLogUser("admin-1", "관리자 1", isAdmin = true)
val app = TripLogApp.open(File(storageDir, "vehicle-1.bin"), user)
val started = app.start(1000.0, Source.SIMULATED)
app.finish(started.id, 1012.0)
app.review(started.id, "거래처 납품", Category.BUSINESS)
val records = app.list()
val csv = app.trips.csv(YearMonth.of(2026, 11))
```

저장소를 교체하려면 StateStore를 구현하고 주입합니다.

```kotlin
val manager = TripLogManager(myStateStore)
val app = TripLogApp(manager, details = ReportDetailStore(reportFile))
app.useUser(user)
```

FileStateStore는 JVM·시제품용 원자적 파일 저장소입니다. 한 파일에 한 프로세스/인스턴스를 사용합니다.
운영 앱에서 Room 등을 사용하려면 StateStore의 load/save를 구현합니다.
보고서 추가 정보 저장은 ReportDetailStore 파일을 사용합니다.
파일 I/O와 코어 호출은 백그라운드 직렬 실행기로 실행하세요. 현재 Android 화면에는 직렬 worker가 있습니다.

## 사용자 변경과 권한

`app.useUser(nextUser)`로 호스트 사용자를 변경합니다. 같은 사용자 입력은 신호 상태를 초기화하지 않습니다.
사용자 변경 시 차량 콜백을 중단하고 변경 완료 후 다시 연결해야 합니다.
진행 중인 운행은 기존 운전자 또는 관리자가 복원할 수 있습니다. 다른 일반 사용자로 변경하면 예외가 발생합니다.
일반 사용자는 자기 기록만 조회·수정하고 관리자는 전체 조회·수정·삭제가 가능합니다.
표시 이름은 화면 표시용이고 기록 소유자는 안정적인 사용자 ID로 판별합니다.
보고서의 이름·부서·차량 등은 `app.reportDetails(tripId, ReportDetails(...))`로 운행별 스냅샷을 전달합니다.

## 차량 입력

`app.distanceMotion.accept(MotionSample(...))`에 검증된 시각, 누적거리(km), 기어, 실제 출처를 전달합니다.
P 기준 → D/R과 거리 증가 → P와 거리 유지 → 종료 확인 흐름입니다.
정차 후보 후 `app.distanceMotion.confirmArrival()`로 사용자의 종료 확인을 전달합니다.
입력 간격은 기본 5초 이하, 정차 유지 시간은 5초입니다. 시각·단위·유효성을 어댑터에서 검증해야 합니다.
콘솔은 SIMULATED, Pleos 테스트 어댑터는 EMULATOR 출처를 사용합니다.

## 이전 호출 변경

- bootstrapAdmin/login/resumeLogin/register/resetPin 등의 계정 API 제거
- `TripLogApp.open(file)` 다음 login 호출 → `TripLogApp.open(file, user)`
- `accountsAndTrips` → `trips`
- `currentAccount()` → `currentUser()`
- `-ProvisionAdmin` 옵션 제거, 시작 스크립트에서 사용자 정보를 매번 입력

월간 HTML은 현재 프로젝트의 보고서 형식이며 국세청 공식 양식과의 완전한 일치 여부는 별도 검증이 필요합니다.
