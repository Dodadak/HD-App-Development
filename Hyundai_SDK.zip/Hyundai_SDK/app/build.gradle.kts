plugins {
    alias(libs.plugins.android.application)
}

android {
    useLibrary("android.car")
    namespace = "com.example.hyundai_sdk"
    compileSdk {
        version = release(37)
    }

    // Shared UI-independent Kotlin core; terminal code is excluded from the Android app.
    sourceSets.named("main") {
        kotlin.directories += "../triplog/core"
    }

    defaultConfig {
        applicationId = "com.example.hyundai_sdk"
        minSdk = 28
        targetSdk = 37
        versionCode = 150
        versionName = "0.14.10"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("ai.pleos.playground:Vehicle:2.3.2")
    implementation("ai.pleos.playground:NaviHelper:3.0.5")
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}