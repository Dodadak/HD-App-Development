package com.example.hyundai_sdk

import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import triplog.Category
import triplog.RecordingMode
import triplog.Source
import triplog.Trip

class DemoTripLogActivity : TripLogActivity() {
    override val demoDate get() = DemoTrips.lastDay
}

internal object DemoTrips {
    private val zone = ZoneId.of("Asia/Seoul")
    private val firstDay = LocalDate.of(2025, 12, 1)
    val lastDay = LocalDate.of(2026, 11, 10)
    private val purposes = listOf(
        "거래처 정기 방문" to Category.BUSINESS,
        "장보기" to Category.PERSONAL,
        "현장 장비 점검" to Category.BUSINESS,
        "업무 물품 배송" to Category.BUSINESS,
        "개인 일정" to Category.PERSONAL,
        "고객사 미팅" to Category.BUSINESS
    )

    fun create(): List<Trip> = buildList {
        var odometerTenths = 126000
        var month = YearMonth.from(firstDay)
        while (!month.atDay(1).isAfter(lastDay)) {
            val days = (1..month.lengthOfMonth() step 3).toList() + month.lengthOfMonth()
            for (dayOfMonth in days.distinct()) {
                val date = month.atDay(dayOfMonth)
                if (date.isBefore(firstDay) || date.isAfter(lastDay)) continue
                val count = if (date == lastDay) 3 else 1
                repeat(count) { slot ->
                    val index = size
                    val start = date.atTime(8 + 4 * slot, (index * 7) % 60).atZone(zone).toInstant()
                    val distanceTenths = 45 + (index * 131) % 640
                    val (purpose, category) = purposes[index % purposes.size]
                    val pending = dayOfMonth == 10 && slot == 0
                    add(Trip(
                        id = "demo-$date-$slot",
                        driverId = TripLogHost.DEMO_DRIVER,
                        start = start,
                        end = start.plusSeconds((22L + distanceTenths / 8) * 60L),
                        startKm = odometerTenths / 10.0,
                        endKm = (odometerTenths + distanceTenths) / 10.0,
                        mode = RecordingMode.SEGMENT,
                        source = Source.SIMULATED,
                        purpose = if (pending) "" else purpose,
                        category = if (pending) Category.UNCLASSIFIED else category,
                        classifier = if (pending) "none" else "manual",
                        confirmed = !pending
                    ))
                    odometerTenths += distanceTenths
                }
            }
            month = month.plusMonths(1)
        }
    }
}
