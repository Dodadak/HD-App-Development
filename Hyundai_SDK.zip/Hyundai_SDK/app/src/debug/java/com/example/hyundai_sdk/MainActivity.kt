package com.example.hyundai_sdk

import android.app.Activity
import triplog.TripLogUser
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Host menu for running this module on its own during the prototype. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = TripLogScreen.readDemoUser(this) ?: TripLogUser("admin-1", "관리자 1", true)
        val density = resources.displayMetrics.density
        val padding = (24 * density).toInt()
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(TextView(this@MainActivity).apply {
                text = "운행일지 UI 테스트 · ${user.displayName}"
                textSize = 27f
                setTextColor(Color.WHITE)
            })
            addView(Button(this@MainActivity).apply {
                text = "운행일지"
                isAllCaps = false
                minimumHeight = (52 * density).toInt()
                setOnClickListener {
                    startActivity(TripLogScreen.intent(this@MainActivity, user))
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = (16 * density).toInt() })
            addView(Button(this@MainActivity).apply {
                text = "더미 운행 기록 열기"
                isAllCaps = false
                minimumHeight = (52 * density).toInt()
                setOnClickListener {
                    isEnabled = false
                    Thread {
                        val result = runCatching {
                            TripLogHost.demoApp(applicationContext, DemoTrips::create)
                        }
                        runOnUiThread {
                            if (isFinishing || isDestroyed) return@runOnUiThread
                            isEnabled = true
                            result.onSuccess {
                                val demo = TripLogScreen.intent(this@MainActivity, user)
                                    .setClass(this@MainActivity, DemoTripLogActivity::class.java)
                                startActivity(demo)
                            }.onFailure {
                                android.util.Log.e("TripLogDemo", "Cannot open demo history", it)
                                android.widget.Toast.makeText(this@MainActivity, "더미 기록을 열 수 없어요.", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = (12 * density).toInt() })
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(17, 21, 27))
            addView(menu)
        })
    }
}
