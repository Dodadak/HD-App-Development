[CmdletBinding()]
param(
    [string]$AvdName,
    [string]$SdkPath,
    [ValidateRange(3, 900)][int]$BootTimeoutSeconds = 180,
    [switch]$ListAvds
)

$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$serial = $null
$consolePort = $null
$currentUser = $null
$stage = 'SDK discovery'
$logDir = $null

function Get-SdkRoot {
    if ($SdkPath) {
        if (-not (Test-Path -LiteralPath (Join-Path $SdkPath 'platform-tools/adb.exe') -PathType Leaf)) {
            throw "No platform-tools/adb.exe under -SdkPath '$SdkPath'."
        }
        return (Resolve-Path -LiteralPath $SdkPath).Path
    }
    $candidates = @()
    $properties = Join-Path $project 'local.properties'
    if (Test-Path -LiteralPath $properties) {
        foreach ($line in Get-Content -LiteralPath $properties) {
            if ($line -match '^\s*sdk\.dir\s*=\s*(.+?)\s*$') {
                $candidates += $Matches[1].Replace('\:', ':').Replace('\\', '\').Replace('\ ', ' ')
                break
            }
        }
    }
    $candidates += @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT)
    if ($env:LOCALAPPDATA) { $candidates += (Join-Path $env:LOCALAPPDATA 'Android/Sdk') }
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath (Join-Path $candidate 'platform-tools/adb.exe') -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    throw 'Android SDK not found. Set -SdkPath to the SDK Location in Android Studio.'
}

function Invoke-Native([string]$File, [string[]]$Arguments, [string]$LogName, [switch]$AllowFailure) {
    # Windows PowerShell can wrap native stderr as ErrorRecords. The process exit code is authoritative.
    $ErrorActionPreference = 'Continue'
    $PSNativeCommandUseErrorActionPreference = $false
    $lines = @(& $File @Arguments 2>&1 | ForEach-Object { $_.ToString() })
    $code = $LASTEXITCODE
    if ($LogName) { $lines | Set-Content -LiteralPath (Join-Path $logDir $LogName) -Encoding UTF8 }
    if ($code -ne 0 -and -not $AllowFailure) {
        throw "$(Split-Path $File -Leaf) exited $code. $($lines -join ' ')"
    }
    if ($code -eq 0) { return $lines }
}

function Read-Emulators {
    $lines = Invoke-Native $adb @('devices', '-l') 'devices.txt'
    foreach ($line in $lines) {
        if ($line -match '^(emulator-\d+)\s+(\S+)') {
            [pscustomobject]@{ Serial = $Matches[1]; State = $Matches[2] }
        }
    }
}

function Read-Property([string]$DeviceSerial, [string]$Property) {
    return ((Invoke-Native $adb @('-s', $DeviceSerial, 'shell', 'getprop', $Property) -AllowFailure) -join '').Trim()
}

function Read-AvdName([string]$DeviceSerial) {
    $names = @(Invoke-Native $adb @('-s', $DeviceSerial, 'emu', 'avd', 'name') -AllowFailure |
        Where-Object { $_.Trim() -and $_.Trim() -ne 'OK' -and $_ -notmatch '^KO:' })
    if ($names.Count -gt 0) { return $names[0].Trim() }
}

function Find-Pleos([object[]]$Devices, [string]$Name) {
    foreach ($device in $Devices) {
        if ($device.State -ne 'device') { continue }
        if ($Name -and (Read-AvdName $device.Serial) -cne $Name) { continue }
        if ((Read-Property $device.Serial 'ro.product.device') -notlike 'crp_avd*') { continue }
        if ((Read-Property $device.Serial 'ro.build.characteristics') -notmatch '(?:^|,)automotive(?:,|$)') { continue }
        $device.Serial
    }
}

function Read-InstalledAvds {
    if (-not (Test-Path -LiteralPath $emulator -PathType Leaf)) {
        throw 'Android Emulator is missing. Install it from SDK Manager.'
    }
    @(Invoke-Native $emulator @('-list-avds') 'avds.txt' |
        ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^[A-Za-z0-9_. -]+$' -and $_ })
}

function Set-DemoUser {
    $id = (Read-Host 'Host user ID (example admin-1)').Trim()
    $name = (Read-Host 'Display name (example Administrator 1)').Trim()
    $role = (Read-Host 'Administrator? [y/n]').Trim().ToLowerInvariant()
    if (-not $id -or $id.Length -gt 200 -or -not $name -or $name.Length -gt 200 -or
        $id -match '[\x00-\x1f\x7f]' -or $name -match '[\x00-\x1f\x7f]' -or $role -notin @('y', 'n')) {
        throw 'Enter a nonempty ID and name (up to 200 characters) and y or n.'
    }
    $payload = @{ id = $id; displayName = $name; isAdmin = ($role -eq 'y') } | ConvertTo-Json -Compress
    $local = Join-Path $logDir 'demo-user.json'
    [IO.File]::WriteAllText($local, $payload, (New-Object Text.UTF8Encoding($false)))
    $remoteFile = '/data/local/tmp/triplog-user-' + [Guid]::NewGuid().ToString('N') + '.json'
    try {
        $null = Invoke-Native $adb @('-s', $serial, 'push', $local, $remoteFile) 'demo-input.txt'
        $command = "run-as com.example.hyundai_sdk --user $currentUser sh -c 'mkdir -p files && cp $remoteFile files/triplog-demo-user.json'"
        $null = Invoke-Native $adb @('-s', $serial, 'shell', $command) 'demo-stage.txt'
    } finally {
        $null = Invoke-Native $adb @('-s', $serial, 'shell', 'rm', '-f', $remoteFile) -AllowFailure
        Remove-Item -LiteralPath $local -ErrorAction SilentlyContinue
    }
}

try {
    $sdk = Get-SdkRoot
    $adb = Join-Path $sdk 'platform-tools/adb.exe'
    $emulator = Join-Path $sdk 'emulator/emulator.exe'
    $runId = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID
    $logDir = Join-Path $project "logs/pleos-triplog-$runId"
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null

    if ($ListAvds) {
        $names = @(Read-InstalledAvds)
        if ($names.Count -eq 0) { throw 'No AVDs found. Create a Pleos Connect AVD in Device Manager.' }
        $names | ForEach-Object { Write-Host $_ }
        return
    }

    Write-Host "Logs: $logDir"
    $stage = 'AVD start'
    Write-Host '[1/5] Start or find the Pleos AVD'
    $null = Invoke-Native $adb @('start-server') 'adb-start.txt'
    $devices = @(Read-Emulators)
    $pleosDevices = @(Find-Pleos $devices $AvdName)
    $process = $null
    if ($pleosDevices.Count -eq 0) {
        # An offline emulator may already be starting. Wait before creating a second instance.
        $bootInProgress = @($devices | Where-Object { $_.State -eq 'offline' }).Count -gt 0
        $sameAvdRunning = $AvdName -and @($devices | Where-Object {
            $_.State -eq 'device' -and (Read-AvdName $_.Serial) -ceq $AvdName
        }).Count -gt 0
        if (-not $bootInProgress -and -not $sameAvdRunning) {
            $installed = @(Read-InstalledAvds)
            if ($installed.Count -eq 0) { throw 'No AVDs found. Create a Pleos Connect AVD in Device Manager.' }
            if (-not $AvdName) {
                if ($installed.Count -ne 1) {
                    throw "Select the Pleos AVD with -AvdName. Installed: $($installed -join ', '). Use -ListAvds to list names."
                }
                $AvdName = $installed[0]
            }
            if ($installed -cnotcontains $AvdName -or $AvdName -notmatch '^[A-Za-z0-9_. -]+$') {
                throw "AVD '$AvdName' was not found. Use -ListAvds for its exact name."
            }
            Write-Host "Launching $AvdName"
            $process = Start-Process -FilePath $emulator -ArgumentList @('-avd', ('"{0}"' -f $AvdName)) -PassThru `
                -RedirectStandardOutput (Join-Path $logDir 'emulator.stdout.txt') `
                -RedirectStandardError (Join-Path $logDir 'emulator.stderr.txt')
        }
    }

    $stage = 'ADB and Android boot'
    Write-Host '[2/5] Wait for Pleos identity, boot completion and active Android user'
    $deadline = (Get-Date).AddSeconds($BootTimeoutSeconds)
    do {
        $pleosDevices = @(Find-Pleos @(Read-Emulators) $AvdName)
        if ($pleosDevices.Count -gt 1) { throw 'Multiple Pleos devices are ready. Specify -AvdName.' }
        if ($pleosDevices.Count -eq 1) {
            $serial = $pleosDevices[0]
            if ((Read-Property $serial 'sys.boot_completed') -eq '1') {
                $currentUser = ((Invoke-Native $adb @('-s', $serial, 'shell', 'am', 'get-current-user') 'user.txt' -AllowFailure) -join '').Trim()
                if ($currentUser -match '^\d+$') { break }
            }
        }
        if ($process -and $process.HasExited -and $process.ExitCode -ne 0) {
            throw "Emulator launch exited $($process.ExitCode). See emulator.stderr.txt."
        }
        Start-Sleep -Seconds 2
    } while ((Get-Date) -lt $deadline)
    if (-not $serial -or $currentUser -notmatch '^\d+$') {
        throw "Pleos did not finish booting within $BootTimeoutSeconds seconds. Check Device Manager and devices.txt."
    }
    Write-Host "Ready: $serial (Android user $currentUser)"

    $stage = 'Virtual Console'
    Write-Host '[3/5] Connect to Virtual Console'
    $forward = ((Invoke-Native $adb @('-s', $serial, 'forward', 'tcp:0', 'tcp:8088') 'console-forward.txt') -join '').Trim()
    if ($forward -notmatch '^\d+$') { throw "Unexpected port-forward result: $forward" }
    $consolePort = $forward
    $consoleUrl = "http://127.0.0.1:$consolePort/"
    $consoleDeadline = (Get-Date).AddSeconds(30)
    $consoleReady = $false
    do {
        try {
            $response = Invoke-WebRequest -Uri $consoleUrl -UseBasicParsing -TimeoutSec 4
            $consoleReady = $response.StatusCode -eq 200
        } catch {
            $_.Exception.Message | Set-Content -LiteralPath (Join-Path $logDir 'console-error.txt') -Encoding UTF8
        }
        if (-not $consoleReady) { Start-Sleep -Seconds 2 }
    } while (-not $consoleReady -and (Get-Date) -lt $consoleDeadline)
    if (-not $consoleReady) { throw "Virtual Console did not respond at $consoleUrl. See console-error.txt." }
    Write-Host "Virtual Console: $consoleUrl"

    $stage = 'APK build and install'
    Write-Host '[4/5] Build and install on the selected emulator'
    Write-Host "Android SDK: $sdk"
    $previousAndroidHome = $env:ANDROID_HOME
    $previousAndroidSdkRoot = $env:ANDROID_SDK_ROOT
    Push-Location $project
    try {
        $env:ANDROID_HOME = $sdk
        $env:ANDROID_SDK_ROOT = $sdk
        $tasks = @(':app:assembleDebug')
        $null = Invoke-Native (Join-Path $project 'gradlew.bat') $tasks 'build.txt'
    } finally {
        $env:ANDROID_HOME = $previousAndroidHome
        $env:ANDROID_SDK_ROOT = $previousAndroidSdkRoot
        Pop-Location
    }
    $apk = Join-Path $project 'app/build/outputs/apk/debug/app-debug.apk'
    if (-not (Test-Path -LiteralPath $apk -PathType Leaf)) { throw 'Expected debug APK was not found. See build.txt.' }
    $install = Invoke-Native $adb @('-s', $serial, 'install', '--user', $currentUser, '-r', $apk) 'install.txt'
    if (($install -join "`n") -notmatch '(?m)^Success\s*$') { throw "APK install was not confirmed. See install.txt." }

    $stage = 'Host user input'
    Set-DemoUser

    $stage = 'App launch'
    Write-Host '[5/5] Open app home'
    $null = Invoke-Native $adb @('-s', $serial, 'shell', 'am', 'force-stop', '--user', $currentUser, 'com.example.hyundai_sdk') 'stop-demo.txt'
    $launch = (Invoke-Native $adb @('-s', $serial, 'shell', 'am', 'start', '-W', '--user', $currentUser,
        '-n', 'com.example.hyundai_sdk/.MainActivity') 'launch.txt') -join "`n"
    if ($launch -notmatch '(?m)^Status:\s*ok\s*$' -or $launch -match '(?im)^Error:|Exception|Status:\s*timeout') {
        throw 'TripLog launch was not confirmed. See launch.txt.'
    }
    Write-Host 'READY FOR MANUAL TEST'
    Write-Host "Virtual Console: $consoleUrl"
    Write-Host 'Set gear P. In the app home, open TripLog before starting navigation guidance.'
    Write-Host 'Return to TripLog and check destination and remaining distance before starting the drive.'
    Write-Host "Navigation diagnostics: & '$adb' -s $serial logcat -d -s 'TripLogNavigation' 'AndroidRuntime'"
} catch {
    $message = "STOPPED at $stage. $($_.Exception.Message)"
    if ($logDir) { $message | Set-Content -LiteralPath (Join-Path $logDir 'failure.txt') -Encoding UTF8 }
    if ($consolePort -and $serial) {
        $null = Invoke-Native $adb @('-s', $serial, 'forward', '--remove', "tcp:$consolePort") -AllowFailure
    }
    Write-Error "$message Logs: $logDir" -ErrorAction Continue
    exit 1
}
