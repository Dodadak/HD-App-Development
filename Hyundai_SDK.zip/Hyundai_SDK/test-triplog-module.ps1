$ErrorActionPreference = 'Stop'
$run = Join-Path $PSScriptRoot ('logs/module-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $run | Out-Null
$classpath = (Join-Path $PSScriptRoot 'triplog/build/triplog-tests.jar') + [IO.Path]::PathSeparator + (Join-Path $PSScriptRoot 'triplog/build/triplog-cli.jar')
& java -cp $classpath triplog.tests.ModuleCheckKt (Join-Path $run 'state.bin')
if ($LASTEXITCODE -ne 0) { throw "Module checks failed. Data: $run" }
Write-Host "Results: $run"
