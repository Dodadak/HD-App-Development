import java.util.UUID

plugins {
    // The Android plugin already provides KGP on the root build classpath.
    kotlin("jvm")
}
java { sourceCompatibility = JavaVersion.VERSION_11; targetCompatibility = JavaVersion.VERSION_11 }
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_11) } }
sourceSets {
    main { kotlin.setSrcDirs(listOf("core", "cli")) }
    test { kotlin.setSrcDirs(listOf("tests")) }
}
tasks.jar {
    archiveFileName.set("triplog-cli.jar")
    destinationDirectory.set(layout.buildDirectory)
    manifest { attributes["Main-Class"] = "triplog.cli.MainKt" }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
    exclude("META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA")
}
tasks.register<JavaExec>("moduleCheck") {
    dependsOn(tasks.testClasses)
    classpath = sourceSets.test.get().runtimeClasspath
    mainClass.set("triplog.tests.ModuleCheckKt")
    val checks = layout.buildDirectory.dir("checks")
    doFirst {
        val state = checks.get().file("${UUID.randomUUID()}.bin").asFile
        args(state.absolutePath)
    }
}

tasks.register<Jar>("testJar") {
    dependsOn(tasks.testClasses)
    archiveFileName.set("triplog-tests.jar")
    destinationDirectory.set(layout.buildDirectory)
    from(sourceSets.test.get().output)
}
