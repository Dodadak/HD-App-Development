package triplog.cli

import triplog.*
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.time.Instant
import java.time.YearMonth

private class EndOfInput : Exception()

private val console = System.console()
private val stdin = BufferedReader(InputStreamReader(System.`in`))

private fun input(prompt: String): String {
    print(prompt)
    System.out.flush()
    val line = if (console != null) console.readLine() else stdin.readLine()
    return line?.trim() ?: throw EndOfInput()
}

fun main(args: Array<String>) {
    try {
        val file = File(args.firstOrNull() ?: input("저장 파일 [data/triplog.bin]: ").ifBlank { "data/triplog.bin" })
        val user = TripLogUser(input("사용자 ID: "), input("표시 이름: "), when (input("관리자 [y/n]: ").lowercase()) {
            "y" -> true
            "n" -> false
            else -> error("y 또는 n을 입력하세요.")
        })
        val app = TripLogApp.open(file, user)
        println("${user.displayName} · 외부 사용자 정보 적용 · 콘솔 차량 입력은 SIMULATED · 거리 km")
        println("help로 명령을 확인하세요.")
        while (true) {
            val line = input("triplog> ")
            if (line == "quit" || line == "exit") break
            if (line.isBlank()) continue
            try {
                val words = line.split(Regex("\\s+"), limit = 3)
                fun tripId() = if (words[1] == "latest") app.list().maxByOrNull { it.start }?.id ?: error("No trips") else words[1]
                when (words[0]) {
                    "help" -> println("""
                        start KM | finish KM | list | pending
                        mode SEGMENT|MANUAL_GROUP
                        review ID|latest  (목적과 BUSINESS/PERSONAL을 직접 입력)
                        motion P|D|R|N KM  (5초 이내 간격으로 신호 입력)
                        arrival  (정차 후보의 종료 확인)
                        details ID|latest  (차량·회사·운전자 정보 입력)
                        export YYYY-MM PATH.csv | report YYYY-MM PATH.html
                        delete ID|latest  (관리자) | quit
                        motion 예시: P 1000 → D 1012 → P 1012 반복, 5초 유지 → arrival
                    """.trimIndent())
                    "start" -> println(app.start(words[1].toDouble(), Source.SIMULATED))
                    "finish" -> println(app.finish(app.list().single { it.end == null }.id, words[1].toDouble()))
                    "list" -> app.list().forEach(::println)
                    "pending" -> app.pending().forEach(::println)
                    "mode" -> app.trips.setMode(RecordingMode.valueOf(words[1]))
                    "review" -> {
                        val id = tripId()
                        val purpose = input("운행 목적 (빈 입력은 보류): ")
                        if (purpose.isNotEmpty()) {
                            val category = input("분류 [BUSINESS/PERSONAL/later]: ")
                            if (category == "later") println(app.defer(id, purpose))
                            else if (input("저장 확정 [y/n]: ").lowercase() == "y")
                                println(app.review(id, purpose, Category.valueOf(category)))
                        }
                    }
                    "motion" -> {
                        val gear = when (words[1]) { "P" -> SelectedGear.PARK; "D" -> SelectedGear.DRIVE
                            "R" -> SelectedGear.REVERSE; "N" -> SelectedGear.NEUTRAL; else -> error("P/D/R/N") }
                        println(app.distanceMotion.accept(MotionSample(Instant.now(), words[2].toDouble(), gear, null, Source.SIMULATED)))
                    }
                    "arrival" -> println(app.distanceMotion.confirmArrival())
                    "details" -> app.reportDetails(tripId(), ReportDetails(
                        input("회사명: "), input("사업자번호: "), input("차종: "), input("차량번호: "),
                        input("부서: "), input("운전자 이름: "), when (input("출퇴근 [y/n]: ")) {
                            "y" -> true; "n" -> false; else -> error("y/n")
                        }))
                    "export" -> File(words[2]).writeText(app.trips.csv(YearMonth.parse(words[1])), Charsets.UTF_8)
                    "report" -> File(words[2]).writeText(app.report(YearMonth.parse(words[1])), Charsets.UTF_8)
                    "delete" -> app.trips.deleteTrip(tripId())
                    else -> println("알 수 없는 명령입니다. help를 입력하세요.")
                }
            } catch (end: EndOfInput) {
                throw end
            } catch (error: Exception) {
                println("ERROR: ${error.message}")
            }
        }
    } catch (_: EndOfInput) {
        println()
    } catch (error: Exception) {
        System.err.println(error.message)
        kotlin.system.exitProcess(1)
    }
}
