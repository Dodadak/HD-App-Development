package triplog.tests
import triplog.*
import java.io.File
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

fun main(args: Array<String>) {
    var checks = 0
    fun verify(value: Boolean) { check(value); checks++ }
    fun denied(action: () -> Unit) { verify(runCatching(action).isFailure) }
    val file = File(args[0])
    val alice = TripLogUser("alice", "운전자 1")
    val bob = TripLogUser("bob", "운전자 2")
    val admin = TripLogUser("host-admin", "관리자 1", true)
    val app = TripLogApp.open(file, alice)
    verify(app.list().isEmpty())
    val trip = app.start(1000.0, Source.SIMULATED)
    denied { app.useUser(bob) }
    verify(app.trips.currentUser() == alice)
    denied { app.start(1001.0, Source.SIMULATED) }
    denied { app.finish(trip.id, 999.0) }
    verify(app.finish(trip.id, 1012.0)?.distanceKm == 12.0)
    app.review(trip.id, "거래처 납품", Category.BUSINESS)
    app.reportDetails(trip.id, ReportDetails("회사", "123", "아이오닉5", "12가3456", "개발", "운전자 1", false))
    verify(app.reportDetails(trip.id)?.plate == "12가3456")
    verify(app.trips.recordingMode() == RecordingMode.SEGMENT)
    val month = YearMonth.from(trip.start.atZone(ZoneId.of("Asia/Seoul")))
    verify(app.report(month).contains("12가3456"))
    app.useUser(bob)
    verify(app.list().isEmpty())
    denied { app.reportDetails(trip.id) }
    denied { app.review(trip.id, "변경", Category.PERSONAL) }
    denied { app.reportDetails(trip.id, ReportDetails("x","x","x","x","x","x",false)) }
    app.useUser(admin)
    verify(app.list().size == 1)
    verify(app.trips.csv(month).contains("거래처 납품"))
    val reopened = TripLogApp.open(file, alice)
    verify(reopened.list().single().confirmed)
    verify(reopened.report(month).contains("거래처 납품"))
    denied { reopened.trips.deleteTrip(trip.id) }
    // Concurrent snapshots reject a second writer instead of overwriting newer records.
    app.trips.setMode(RecordingMode.MANUAL_GROUP)
    denied { reopened.trips.setMode(RecordingMode.MANUAL_GROUP) }
    var time = Instant.parse("2026-11-10T00:00:00Z")
    val manager = TripLogManager(MemoryStore(), now = { time }).apply { useUser(alice) }
    val motion = MotionTripRecorder(manager, now = { time }, evidence = MotionEvidence.ODOMETER_INCREASE)
    fun signal(gear: SelectedGear, km: Double): SignalResult {
        time = time.plusSeconds(1)
        return motion.accept(MotionSample(time, km, gear, null, Source.SIMULATED))
    }
    verify(signal(SelectedGear.PARK, 1000.0).status == "MOTION_BASELINE_READY")
    verify(signal(SelectedGear.DRIVE, 1012.0).status == "MOTION_STARTED")
    repeat(5) { signal(SelectedGear.PARK, 1012.0) }
    verify(signal(SelectedGear.PARK, 1012.0).status == "MOTION_ARRIVAL_CONFIRM_REQUIRED")
    verify(motion.confirmArrival().trip?.distanceKm == 12.0)
    manager.setMode(RecordingMode.MANUAL_GROUP)
    verify(manager.recordingMode() == RecordingMode.MANUAL_GROUP)
    signal(SelectedGear.PARK, 1012.0)
    signal(SelectedGear.DRIVE, 1014.0)
    repeat(6) { signal(SelectedGear.PARK, 1014.0) }
    verify(motion.confirmArrival().status == "MOTION_GROUP_CONTINUES")
    verify(motion.confirmArrival(finishGroup = true).trip?.distanceKm == 2.0)
    if (args.size > 1) {
        val legacy = TripLogApp.open(File(args[1]), admin)
        verify(legacy.list().single().distanceKm == 12.0)
        verify(FileStateStore(File(args[1])).load().accounts.isEmpty())
    }
    println("PASS $checks checks: external identity, ownership, recovery, report, concurrent writer, motion (legacy when fixture supplied)")
}
